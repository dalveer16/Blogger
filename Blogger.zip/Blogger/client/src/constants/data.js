export const categories = ["Music", "Movies", "Sports", "Tech", "Fashion"];

export const AUTH = "AUTH";
export const LOGOUT = "LOGOUT";